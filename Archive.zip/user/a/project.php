<?php
$path = "/tms";
$page = "projects";


if (isset($_GET["slug"]) && strlen(trim($_GET["slug"])) > 5) {
    $slug = $_GET["slug"];
}



use app\utils\Helper;

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);




include '../../vendor/autoload.php';
$total_report = 500;
$followers = 930;
$comments = 398;
$likes = 93893;
$o_report = 0;
$o_comments = 4930;
$o_followers = 3394;

$threatCount = 0;

// session_start();
// if (isset($_SESSION["is_logged_in"]) && $_SESSION["is_logged_in"] && isset($_SESSION["user"]) && is_array($_SESSION["user"]) && count($_SESSION["user"]) == 8) {

//     $controller = new ThreatController();

//     $o_report = $controller->getCount();
//     $total_report = $controller->getMyCount((int) $_SESSION["user"]['user_id']);
// } else {
//     header("location: ./login.php");
// }



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Account - TMS</title>
    <link rel="stylesheet" href="../../static/styles/dashboard.css">
</head>

<body>
    <div class="container">
        <?php include_once('./include/header.php') ?>
        <main>
            <header>
                <div class="bars">
                    <svg id="openMenu" data-slot="icon" fill="none" stroke-width="1.5" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"></path>
                    </svg>
                    <h1>Project list</h1>
                </div>
                <div class="side_menu">
                    <a href="./create-project.php">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m3.75 9v6m3-3H9m1.5-12H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" />
                        </svg>
                        <span>Start a project</span>
                    </a>
                    <a href="">
                        <div class="image_holder">
                            <?php
                            // $pic = $threat["user_picture"];
                            // if ($pic !== NULL && strlen(trim($pic)) > 9) {
                            //     echo " <img src='" . Helper::loadImage($pic) . "' alt='' /> ";
                            // } else echo Helper::getInitialNames($threat["user_fullname"]);
                            echo Helper::getInitialNames("Amaka Emmanuel");
                            ?>
                        </div>
                    </a>
                </div>

            </header>
            <div class="content">

                <section id="page_num">
                    <p> <strong>Count:</strong> <?php echo number_format(9562); ?></p>

                    <a href="./create-project.php">
                        Start a new project
                    </a>
                </section>

                <section id="list">
                    <h3>List of Completed Projects</h3>
                    <ul>
                        <li>
                            <p class="line-clamp-2">Lorem ipsum dolor sit, amet consectetur adipisicing elit.</p>
                            <div class="li_task">
                                <span>20 Task(s)</span>
                                <span>30%</span>
                            </div>
                            <div class="li_task">
                                <div class="users">
                                    <ul>
                                        <li>
                                            <div class="image_holder">
                                                <img src="../../static/images/no-image.png" alt="">
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <span> 13 Nov / 10 Dec </span>
                            </div>
                            <label></label>
                        </li>
                        <li>
                            <p class="line-clamp-2">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quasi sed cupiditate ex doloribus.</p>
                            <div class="li_task">
                                <span>20 Task(s)</span>
                                <span>30%</span>
                            </div>
                            <div class="li_task">
                                <div class="users">
                                    <ul>
                                        <li>
                                            <div class="image_holder">AC</div>
                                        </li>
                                        <li>
                                            <div class="image_holder">
                                                <img src="../../static/images/no-image.png" alt="">
                                            </div>
                                        </li>
                                        <li>
                                            <div class="image_holder">
                                                <img src="../../static/images/no-image.png" alt="">
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <span> 13 Nov / 10 Dec </span>
                            </div>
                            <label style="background-color: #9382FF;"></label>
                        </li>
                        <li>
                            <p class="line-clamp-2">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quasi sed cupiditate ex doloribus.</p>
                            <div class="li_task">
                                <span>20 Task(s)</span>
                                <span>30%</span>
                            </div>
                            <div class="li_task">
                                <div class="users">
                                    <ul>
                                        <li>
                                            <div class="image_holder">AC</div>
                                        </li>
                                        <li>
                                            <div class="image_holder">
                                                <img src="../../static/images/no-image.png" alt="">
                                            </div>
                                        </li>
                                        <li>
                                            <div class="image_holder">AC</div>
                                        </li>
                                        <li>
                                            <div class="image_holder">
                                                <img src="../../static/images/no-image.png" alt="">
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <span> 13 Nov / 10 Dec </span>
                            </div>
                            <label style="background-color: greenyellow;"></label>
                        </li>
                    </ul>
                </section>

            </div>

            <footer>
                &copy; <?php echo date("Y") ?> -- Task Management System (TMS)
            </footer>
        </main>
    </div>

</body>


<script>
    const closeMenu = document.querySelector("#closeMenu");
    const openMenu = document.querySelector("#openMenu");

    openMenu.addEventListener("click", function() {
        document.querySelector("aside").classList.toggle("showMenu");
    });
    closeMenu.addEventListener("click", function() {
        document.querySelector("aside").classList.toggle("showMenu");
    });


    // document.addEventListener("DOMContentLoaded", () => {
    //     const innerLines = document.querySelectorAll('.inner-line');

    //     innerLines.forEach(innerLine => {
    //         const percentage = innerLine.getAttribute('percentage');
    //         if (percentage) {
    //             innerLine.style.setProperty('--percentage-width', percentage);
    //         }
    //     });
    // });
</script>

</html>
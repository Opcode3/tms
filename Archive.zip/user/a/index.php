<?php
$path = "/tms";
$page = "dashboard";


use app\utils\Helper;

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);




include '../../vendor/autoload.php';
$total_report = 500;
$followers = 930;
$comments = 398;
$likes = 93893;
$o_report = 0;
$o_comments = 4930;
$o_followers = 3394;

$threatCount = 0;

// session_start();
// if (isset($_SESSION["is_logged_in"]) && $_SESSION["is_logged_in"] && isset($_SESSION["user"]) && is_array($_SESSION["user"]) && count($_SESSION["user"]) == 8) {

//     $controller = new ThreatController();

//     $o_report = $controller->getCount();
//     $total_report = $controller->getMyCount((int) $_SESSION["user"]['user_id']);
// } else {
//     header("location: ./login.php");
// }



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Account - TMS</title>
    <link rel="stylesheet" href="../../static/styles/dashboard.css">
</head>

<body>
    <div class="container">
        <?php include_once('./include/header.php') ?>
        <main>
            <header>
                <div class="bars">
                    <svg id="openMenu" data-slot="icon" fill="none" stroke-width="1.5" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"></path>
                    </svg>
                    <h1>Dashboard</h1>
                </div>
                <div class="side_menu">
                    <a href="./create-project.php">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m3.75 9v6m3-3H9m1.5-12H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" />
                        </svg>
                        <span>Start a project</span>
                    </a>
                    <a href="">
                        <div class="image_holder">
                            <?php
                            // $pic = $threat["user_picture"];
                            // if ($pic !== NULL && strlen(trim($pic)) > 9) {
                            //     echo " <img src='" . Helper::loadImage($pic) . "' alt='' /> ";
                            // } else echo Helper::getInitialNames($threat["user_fullname"]);
                            echo Helper::getInitialNames("Amaka Emmanuel");
                            ?>
                        </div>
                    </a>
                </div>

            </header>
            <div class="content">
                <section style="padding-bottom:0px; margin-bottom:-25px;">
                    <h2>Hello, Ernest</h2>

                </section>
                <section id="statistics">
                    <h3>Statistics</h3>
                    <ul>
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 12.75V12A2.25 2.25 0 0 1 4.5 9.75h15A2.25 2.25 0 0 1 21.75 12v.75m-8.69-6.44-2.12-2.12a1.5 1.5 0 0 0-1.061-.44H4.5A2.25 2.25 0 0 0 2.25 6v12a2.25 2.25 0 0 0 2.25 2.25h15A2.25 2.25 0 0 0 21.75 18V9a2.25 2.25 0 0 0-2.25-2.25h-5.379a1.5 1.5 0 0 1-1.06-.44Z" />
                            </svg>
                            <div class="info">
                                <strong>Total Projects</strong>
                                <p><?php echo number_format(2) ?></p>
                            </div>
                            <div class="line"></div>
                        </li>
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 0 1 3 19.875v-6.75ZM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 0 1-1.125-1.125V8.625ZM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 0 1-1.125-1.125V4.125Z" />
                            </svg>
                            <div class="info">
                                <strong>Completed Projects</strong>
                                <p><?php echo number_format(1) ?></p>
                            </div>
                            <div class="line"></div>
                        </li>
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" />
                            </svg>
                            <div class="info">
                                <strong>Created Task</strong>
                                <p><?php echo number_format(10) ?></p>
                            </div>
                            <div class="line"></div>
                        </li>
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 18 9 11.25l4.306 4.306a11.95 11.95 0 0 1 5.814-5.518l2.74-1.22m0 0-5.94-2.281m5.94 2.28-2.28 5.941" />
                            </svg>
                            <div class="info">
                                <strong>Assigned Task</strong>
                                <p><?php echo number_format(7) ?></p>
                            </div>
                            <div class="line"></div>
                        </li>
                        <li>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 0 1 3 19.875v-6.75ZM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 0 1-1.125-1.125V8.625ZM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 0 1-1.125-1.125V4.125Z" />
                            </svg>
                            <div class="info">
                                <strong>Completed Task</strong>
                                <p><?php echo number_format(1) ?></p>
                            </div>
                            <div class="line"></div>
                        </li>
                    </ul>
                </section>

                <section id="list">
                    <h3>List of Ongoing Projects</h3>
                    <ul>
                        <li>
                            <a href="./project.php?slug=">
                                <p class="line-clamp-2">Design the banner for the twitter lead campaign</p>
                                <div class="li_task">
                                    <span>2 Task(s)</span>
                                    <span>10%</span>
                                </div>
                                <div class="li_task">
                                    <div class="users">
                                        <ul>
                                            <li>
                                                <div class="image_holder">
                                                    <img src="../../static/images/no-image.png" alt="">
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <span> 01 Aug / 20 Aug </span>
                                </div>
                                <label></label>
                            </a>
                        </li>
                        <li>
                            <a href="./project.php?slug=">
                                <p class="line-clamp-2">Rebrand the sales and convertion page for the QRX event</p>
                                <div class="li_task">
                                    <span>8 Task(s)</span>
                                    <span>0%</span>
                                </div>
                                <div class="li_task">
                                    <div class="users">
                                        <ul>
                                            <li>
                                                <div class="image_holder">AC</div>
                                            </li>
                                            <li>
                                                <div class="image_holder">
                                                    <img src="../../static/images/no-image.png" alt="">
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <span> 13 Nov / 10 Dec </span>
                                </div>
                                <label style="background-color: #9382FF;"></label>
                            </a>
                        </li>
                    </ul>

                </section>

            </div>

            <footer>
                &copy; <?php echo date("Y") ?> -- Task Management System (TMS)
            </footer>
        </main>
    </div>

</body>


<script>
    const closeMenu = document.querySelector("#closeMenu");
    const openMenu = document.querySelector("#openMenu");

    openMenu.addEventListener("click", function() {
        document.querySelector("aside").classList.toggle("showMenu");
    });
    closeMenu.addEventListener("click", function() {
        document.querySelector("aside").classList.toggle("showMenu");
    });


    // document.addEventListener("DOMContentLoaded", () => {
    //     const innerLines = document.querySelectorAll('.inner-line');

    //     innerLines.forEach(innerLine => {
    //         const percentage = innerLine.getAttribute('percentage');
    //         if (percentage) {
    //             innerLine.style.setProperty('--percentage-width', percentage);
    //         }
    //     });
    // });
</script>

</html>